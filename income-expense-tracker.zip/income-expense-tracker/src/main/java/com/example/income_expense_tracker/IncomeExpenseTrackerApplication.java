package com.example.income_expense_tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IncomeExpenseTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(IncomeExpenseTrackerApplication.class, args);
	}

}
